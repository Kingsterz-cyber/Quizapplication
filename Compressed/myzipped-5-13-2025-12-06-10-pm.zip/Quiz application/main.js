document.addEventListener('DOMContentLoaded', () => {
    // Navbar scroll effect
    window.addEventListener('scroll', function () {
        const navbar = document.getElementById('navbar');
        navbar.classList.toggle('scrolled', window.scrollY > 50);
    });

    // Animate .card-1 on scroll
    const cards = document.querySelectorAll('.card-1');
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('show');
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.3 });

    cards.forEach((card, index) => {
        card.style.transitionDelay = `${index * 0.2}s`;
        observer.observe(card);
    });

    // Show category page
    const startQuizButtons = document.querySelectorAll('.button1');
    const slidingPage = document.getElementById('slidingPage');
    startQuizButtons.forEach(button => {
        button.addEventListener('click', () => {
            slidingPage.classList.add('active');
        });
    });

    // Show subcategories
    const categoryCards = document.querySelectorAll('.card-category-home');
    const subCategoryCards = document.querySelectorAll('.card-category-card');
    const slidingCardsPage = document.getElementById('slidingCardsPage');
    const returnFromCategory = document.getElementById('exitbutton');
    const returnHome = document.getElementById('exitButton');

    categoryCards.forEach(categoryCard => {
        categoryCard.addEventListener('click', () => {
            const selectedCategory = categoryCard.getAttribute('data-category');
            slidingCardsPage.classList.add('active');

            subCategoryCards.forEach(card => {
                const cardCategory = card.getAttribute('data-category');
                card.classList.toggle('show', cardCategory === selectedCategory);
            });
        });
    });

    returnFromCategory?.addEventListener('click', () => {
        slidingCardsPage.classList.remove('active');
    });

    returnHome?.addEventListener('click', () => {
        slidingPage.classList.remove('active');
    });

    // Quiz logic
    
    const quizCards = document.querySelectorAll('.card-category-card'); // Select all subcategory cards
    const slidingQuizPage = document.getElementById('slidingQuizPage'); // Quiz page container
    const questionBox = document.getElementById('questionBox'); // Question box
    const optionsContainer = document.getElementById('optionsContainer'); // Options container
    const progressBar = document.getElementById('progressBar'); // Progress bar
    const progressText = document.getElementById('progressText'); // Progress text
    const nextButton = document.getElementById('nextButton'); // Next button

    const allQuestions = {
        "world-facts": [
            { question: "What is the largest ocean?", options: ["Atlantic", "Pacific", "Indian", "Arctic"], correct: 1 },
            { question: "What is the capital of Canada?", options: ["Toronto", "Ottawa", "Vancouver", "Montreal"], correct: 1 },
            { question: "Which country is known as the Land of the Rising Sun?", options: ["China", "Japan", "Thailand", "South Korea"], correct: 1 },
            { question: "What is the smallest country in the world?", options: ["Vatican City", "Monaco", "Nauru", "Malta"], correct: 0 },
            { question: "Which continent is known as the Dark Continent?", options: ["Asia", "Africa", "South America", "Australia"], correct: 1 },
            { question: "What is the longest river in the world?", options: ["Amazon", "Nile", "Yangtze", "Mississippi"], correct: 1 },
            { question: "Which country has the most natural lakes?", options: ["Canada", "USA", "Russia", "India"], correct: 0 },
            { question: "What is the largest desert in the world?", options: ["Sahara", "Arabian", "Gobi", "Kalahari"], correct: 0 },
            { question: "Which country is home to the kangaroo?", options: ["Australia", "New Zealand", "USA", "Canada"], correct: 0 },
            { question: "What is the capital of Australia?", options: ["Sydney", "Canberra", "Melbourne", "Brisbane"], correct: 1 }
        ],
       "movies-series": [
    { question: "Who directed Titanic?", options: ["James Cameron", "Spielberg", "Nolan", "Bay"], correct: 0 },
    { question: "What is the highest-grossing film of all time?", options: ["Avatar", "Titanic", "Star Wars", "Avengers: Endgame"], correct: 0 },
    { question: "Who played the Joker in 'The Dark Knight'?", options: ["Jared Leto", "Heath Ledger", "Joaquin Phoenix", "Jack Nicholson"], correct: 1 },
    { question: "Which actor played Iron Man in the MCU?", options: ["Chris Evans", "Robert Downey Jr.", "Chris Hemsworth", "Mark Ruffalo"], correct: 1 },
    { question: "Which of these is NOT a Quentin Tarantino film?", options: ["Pulp Fiction", "The Hateful Eight", "No Country for Old Men", "Kill Bill"], correct: 2 },
    { question: "Who won Best Actor Oscar for 'Joker' (2019)?", options: ["Leonardo DiCaprio", "Joaquin Phoenix", "Adam Driver", "Antonio Banderas"], correct: 1 },
    { question: "Which TV show features the Red Wedding?", options: ["Vikings", "The Witcher", "Game of Thrones", "Outlander"], correct: 2 },
    { question: "What is the highest-grossing animated film of all time?", options: ["Frozen II", "The Lion King (2019)", "Demon Slayer: Mugen Train", "Minions"], correct: 2 },
    { question: "Which director created the 'Dark Universe' series?", options: ["Christopher Nolan", "Guillermo del Toro", "Baran bo Odar", "David Fincher"], correct: 2 },
    { question: "What was the first Marvel movie in the MCU?", options: ["Spider-Man", "X-Men", "Iron Man", "The Incredible Hulk"], correct: 2 }
],
        "programming-basics": [
            { question: "What does HTML stand for?", options: ["Hyper Text Markup Language", "High Text Markup Language", "Hyper Tabular Markup Language", "None of these"], correct: 0 },
            { question: "Which language is used for styling web pages?", options: ["HTML", "CSS", "JavaScript", "XML"], correct: 1 },
            { question: "Which is not a programming language?", options: ["Python", "Java", "HTML", "C++"], correct: 2 },
            { question: "What does CSS stand for?", options: ["Cascading Style Sheets", "Colorful Style Sheets", "Creative Style Sheets", "Computer Style Sheets"], correct: 0 },
            { question: "Which HTML tag is used to define an internal style sheet?", options: ["<style>", "<css>", "<script>", "<link>"], correct: 0 },
            { question: "Which is the correct CSS syntax?", options: ["body {color: black;}", "{body;color:black;}", "{body;color:black;}", "body:color=black;"], correct: 0 },
            { question: "How do you insert a comment in a CSS file?", options: ["// this is a comment", "<!-- this is a comment -->", "/ this is a comment /", "* this is a comment *"], correct: 2 },
            { question: "Which property is used to change the background color?", options: ["bgcolor", "color", "background-color", "background"], correct: 2 },
            { question: "How do you select an element with id 'demo' in CSS?", options: ["#demo", ".demo", "*demo*", "@demo"], correct: 0 },
            { question: "Which HTML attribute is used to define inline styles?", options: ["class", "style", "font", "styles"], correct: 1 }

        ],
        "History": [
            { question: "Who was the first President of the United States?", options: ["George Washington", "Thomas Jefferson", "Abraham Lincoln", "John Adams"], correct: 0 },
            { question: "What year did World War II end?", options: ["1945", "1944", "1946", "1947"], correct: 0 },
            { question: "Who discovered America?", options: ["Christopher Columbus", "Ferdinand Magellan", "Marco Polo", "Leif Erikson"], correct: 0 },
            { question: "What was the ancient name of Egypt?", options: ["Kemet", "Nubia", "Cush", "Pharaoh"], correct: 0 },
            { question: "Who was known as the Iron Lady?", options: ["Margaret Thatcher", "Angela Merkel", "Indira Gandhi", "Golda Meir"], correct: 0 },
            { question: "Which empire was known for its road system?", options: ["Roman Empire", "Ottoman Empire", "Mongol Empire", "British Empire"], correct: 0 },
            { question: "What was the main cause of the French Revolution?", options: ["Taxation without representation", "Social inequality", "Monarchy's absolute power", "All of the above"], correct: 3 },
            { question: "Who wrote 'The Art of War'?", options: ["Sun Tzu", "Confucius", "Laozi", "Mencius"], correct: 0 },
            { question: "What was the first civilization in Mesopotamia?", options: ["Sumerians", "Babylonians", "Assyrians", "Akkadians"], correct: 0 },
            { question: "In what year did World War II end?", options: ["1945", "1944", "1946", "1947"], correct: 0 },
        ],
        "famous-people": [
           
            { question: "Who invented the telephone?", options: ["Alexander Graham Bell", "Thomas Edison", "Nikola Tesla", "Guglielmo Marconi"], correct: 0 },
            { question: "Who is known for the theory of relativity?", options: ["Isaac Newton", "Albert Einstein", "Galileo Galilei", "Stephen Hawking"], correct: 1 },
            { question: "Who is known as the Father of Modern Physics?", options: ["Isaac Newton", "Albert Einstein", "Galileo Galilei", "Niels Bohr"], correct: 1 },
            { question: "Who painted the Mona Lisa?", options: ["Vincent van Gogh", "Pablo Picasso", "Leonardo da Vinci", "Claude Monet"], correct: 2 },
            { question: "Who wrote 'Romeo and Juliet'?", options: ["Charles Dickens", "William Shakespeare", "Mark Twain", "Jane Austen"], correct: 1 },
            { question: "Who was the first person to walk on the moon?", options: ["Neil Armstrong", "Buzz Aldrin", "Yuri Gagarin", "Michael Collins"], correct: 0 },
            { question: "Who is known as the King of Pop?", options: ["Elvis Presley", "Michael Jackson", "Prince", "Freddie Mercury"], correct: 1 },
            { question: "Who was the first female Prime Minister of the UK?",options: ["Queen Elizabeth II", "Theresa May", "Margaret Thatcher", "Angela Merkel"],correct: 2 },
            { question: "Who is known for the theory of evolution?", options: ["Charles Darwin", "Gregor Mendel", "Louis Pasteur", "Albert Einstein"], correct: 0 },
            { question: "Who wrote 'The Great Gatsby'?", options: ["F. Scott Fitzgerald", "Ernest Hemingway", "Mark Twain", "John Steinbeck"], correct: 0 },
            
        ],
        "Cartoons": [
            { question: "What is Boss Baby's real name in the movie?",options: ["Timothy Templeton", "Theodore Templeton", "Teddy Templeton", "Tommy Templeton"],correct: 1,},
            { question: "In 'The Lion King', who is Simba's father?",options: ["Scar", "Mufasa", "Rafiki", "Zazu"],correct: 1,},
            { question: "What is the name of the main character in 'Finding Nemo'?",options: ["Dory", "Nemo", "Marlin", "Bruce"],correct: 2,},
            { question: "In 'Toy Story', what is the name of the cowboy doll?",options: ["Buzz Lightyear", "Woody", "Mr. Potato Head", "Rex"],correct: 1,},
            { question: "What is the name of the princess in 'Frozen'?",options: ["Elsa", "Anna", "Ariel", "Belle"], correct: 0,},
            { question: "In 'SpongeBob SquarePants', what is SpongeBob's job?",options: ["Fry Cook", "Lifeguard", "Teacher", "Scientist"],correct: 0,},
            { question: "Which company created the Barbie animated movies?", options: ["Disney", "DreamWorks", "Mattel", "Nickelodeon"],},
            { question: "What energy attack is Goku most famous for in Dragon Ball?", options: ["Kamehameha", "Spirit Bomb", "Final Flash", "Destructo Disc"],correct: 0,}
           
        ],
        "Celebrities":[
          { question: "Which Kendrick Lamar album won the Pulitzer Prize?", options: ["DAMN.", "To Pimp a Butterfly", "good kid, m.A.A.d city", "Mr. Morale & The Big Steppers"], correct: 1, },
          { question: "What is Kendrick Lamar's birth name?", options: ["Kendrick Lamar Duckworth", "Kendrick Lamar Jackson", "Kendrick Lamar Carter", "Kendrick Lamar Graham"], correct: 0, },
          { question: "Which celebrity couple was known as 'Bennifer'?", options: ["Brad Pitt & Jennifer Aniston", "Ben Affleck & Jennifer Lopez", "Ben Stiller & Jennifer Lawrence", "Ben Barnes & Jennifer Garner"], correct: 1, },
          { question: "Which artist has the most Grammy wins of all time?", options: ["Beyoncé", "Michael Jackson", "Stevie Wonder", "Taylor Swift"], correct: 0, },
          { question: "Who was the first female artist to headline Coachella?", options: ["Lady Gaga", "Beyoncé", "Rihanna", "Ariana Grande"], correct: 1, },
          { question: "Which celebrity founded the makeup brand Fenty Beauty?", options: ["Kim Kardashian", "Rihanna", "Kylie Jenner", "Selena Gomez"], correct: 1, },
          { question: "What was the name of Taylor Swift's first album?", options: ["Fearless", "Taylor Swift", "Debut", "Speak Now"], correct: 1, },
          { question: "Which rapper is known as 'Drizzy'?", options: ["Kanye West", "Drake", "Travis Scott", "Lil Wayne"], correct: 1, },
          { question: "Which celebrity has the most followers on Instagram?", options: ["Cristiano Ronaldo", "Kylie Jenner", "Lionel Messi", "Selena Gomez"], correct: 0, },
          { question: "What is the name of Kendrick Lamar's record label?", options: ["Top Dawg Entertainment", "Aftermath", "Interscope", "Dreamville"], correct: 0, },
        ],
        "awards-festivals":[

           {question:"What is the Grammy Award trophy shaped like?",options:["Gramophone","Microphone","Gold record","Star"],correct:0},
           {question:"Which film festival awards the Palme d'Or?",options:["Venice","Berlin","Cannes","Toronto"],correct:2},
           {question:"What color is the carpet at the Met Gala?",options:["Red","White","Black","Gold"],correct:0},
           {question:"What was the first year the BET Awards were held?",options:["1998","2001","2005","2010"],correct:1},
           {question:"Which Grammy category was introduced in 2023 for African music?",options:["Best Afrobeats","Best Global Music","Best African Performance","Best Amapiano"],correct:1},
           {question:"Which artist has won the most BET Hip Hop Awards?",options:["Kendrick Lamar","Drake","Jay-Z","Kanye West"],correct:0},
           {question:"What special Grammy did Michael Jackson win in 1984?",options:["Legend Award","Record of the Year","Album of the Year","Video Vanguard"],correct:0},
           {question:"Which artist won the first-ever BET Award for Best Female R&B?",options:["Mary J. Blige","Alicia Keys","Beyoncé","Rihanna"],correct:0},
           {question:"How many main Grammy categories are there currently?",options:["84","65","94","102"],correct:2},
           {question:"Where is the Sundance Film Festival held annually?",options:["Colorado","Utah","California","New York"],correct:1},
           {question:"Which music festival is known for its pyramid stage?",options:["Coachella","Glastonbury","Lollapalooza","Bonnaroo"],correct:1}
        ],
        "computers-internet":[
           {question:"What does 'www' stand for in websites?",options:["World Wide Web","Web World Wide","Wide World Web","World Web Wide"],correct:0,},
           {question:"Which company created Windows?",options:["Apple","Microsoft","Google","IBM"],correct:1,},
           {question:"What is the most popular web browser?",options:["Safari","Chrome","Firefox","Edge"],correct:1,},
           {question:"What does 'URL' stand for?",options:["Uniform Resource Locator","Universal Reference Link","Uniform Reference Locator","Universal Resource Location"],correct:0,},
           {question:"Which programming language is known for web development?",options:["Java","Python","HTML","C++"],correct:2,},
           {question:"What is the main purpose of a firewall?",options:["Speed up internet","Block viruses","Organize files","Create backups"],correct:1,},
           {question:"What year was the first iPhone released?",options:["2005","2007","2009","2011"],correct:1,},
           {question:"Which protocol secures website connections?",options:["HTTP","FTP","HTTPS","SMTP"],correct:2,},
           {question:"What does 'GPU' stand for?",options:["Graphic Processing Unit","General Processing Unit","Global Processing Unit","Graphical Performance Unit"],correct:0,},
           {question:"Which company developed the Python language?",options:["Microsoft","Google","Python Software Foundation","Oracle"],correct:2}
        ],
        "inventions":[
        
          {question:"Who invented the telephone?",options:["Thomas Edison","Alexander Graham Bell","Nikola Tesla","Guglielmo Marconi"],correct:1},
          {question:"Who invented the light bulb?",options:["Thomas Edison","Nikola Tesla","Benjamin Franklin","James Watt"],correct:0},
          {question:"What did the Wright brothers invent?",options:["Automobile","Telephone","Airplane","Radio"],correct:2},
          {question:"Who invented the printing press?",options:["Benjamin Franklin","Leonardo da Vinci","Johannes Gutenberg","Galileo Galilei"],correct:2},


          {question:"Which invention is Tim Berners-Lee known for?",options:["Email","World Wide Web","JavaScript","Linux"],correct:1},
          {question:"Who invented the first computer algorithm?",options:["Alan Turing","Charles Babbage","Ada Lovelace","Bill Gates"],correct:2},
          {question:"What did Johannes Gutenberg invent?",options:["Steam Engine","Printing Press","Telegraph","Microscope"],correct:1},


         {question:"Who invented the first programmable computer?",options:["Konrad Zuse","Charles Babbage","Alan Turing","John Atanasoff"],correct:0},
         {question:"Which inventor created the first working television?",options:["Philo Farnsworth","Thomas Edison","Guglielmo Marconi","Alexander Graham Bell"],correct:0},
         {question:"Who invented the first successful polio vaccine?",options:["Marie Curie","Jonas Salk","Louis Pasteur","Alexander Fleming"],correct:1}
        ],
        "graphic-design":[
          {question:"Which tool is most used in graphic design?",options:["Adobe Photoshop","Microsoft Word","Google Docs","Windows Paint"],correct:0},
          {question:"What does 'RGB' stand for?",options:["Red Green Blue","Royal Gold Bronze","Rich Gradient Blend","Raster Graphic Bit"],correct:0},
          {question:"Which file format supports transparency?",options:["JPG","PNG","BMP","GIF"],correct:1},
          {question:"Which color model is used for digital screens?",options:["CMYK","RGB","HSB","LAB"],correct:1},
          {question:"What is kerning in typography?",options:["Line spacing","Letter spacing","Font weight","Text alignment"],correct:1},
          {question:"Which design principle creates visual hierarchy?",options:["Contrast","Repetition","Alignment","Proximity"],correct:0},
          {question:"What does 'DPI' measure?",options:["Color depth","Image resolution","File size","Aspect ratio"],correct:1},
          {question:"Which color model is used for print design?",options:["RGB","CMYK","HSV","Pantone"],correct:1},
          {question:"What is the golden ratio in design?",options:["1:1.618","3:4","16:9","2:3"],correct:0},
          {question:"Who designed the 'I Love NY' logo?",options:["Paul Rand","Milton Glaser","Saul Bass","Massimo Vignelli"],correct:1}
        ],
        "basketball":[
            
         {question:"How many points is a three-point shot worth?",options:["1","2","3","4"],correct:2},
         {question:"Which position is typically the tallest player?",options:["Point Guard","Shooting Guard","Small Forward","Center"],correct:3},
         {question:"How many players are on the court per team?",options:["4","5","6","7"],correct:1},
         {question:"Which NBA team has the most championships?",options:["Lakers","Celtics","Bulls","Warriors"],correct:1},

         {question:"Who holds the record for most points in a single game?",options:["Michael Jordan","Kobe Bryant","Wilt Chamberlain","LeBron James"],correct:2},
         {question:"What is the diameter of a basketball hoop in inches?",options:["12","15","18","24"],correct:2},
         {question:"Which player is known as 'The Greek Freak'?",options:["Luka Dončić","Giannis Antetokounmpo","Nikola Jokić","Joel Embiid"],correct:1},

         {question:"Who was the first NBA player to score 100 points in a game?",options:["Kareem Abdul-Jabbar","Wilt Chamberlain","Bill Russell","Oscar Robertson"],correct:1},
         {question:"Which year was the NBA founded?",options:["1946","1950","1960","1976"],correct:0},
         {question:"Which player holds the record for most career assists?",options:["Magic Johnson","John Stockton","Jason Kidd","Chris Paul"],correct:1}
        ],
        "digital-safety":[
        
         {question:"What is the best way to create a strong password?",options:["Use your pet's name","Combine random words and numbers","Use 'password123'","Write it on a sticky note"],correct:1},
         {question:"What does 'HTTPS' in a website URL indicate?",options:["The site is old","The connection is secure","The site is government-run","The site is free to use"],correct:1},
         {question:"What should you do before clicking a link in an email?",options:["Check the sender's address","Click immediately if it looks interesting","Forward it to friends","Download any attachments"],correct:0},
         {question:"Why is two-factor authentication important?",options:["It makes logging in faster","It adds an extra layer of security","It reduces your phone's battery life","It's required by all websites"],correct:1},


         {question:"What is a 'phishing' attack?",options:["A fishing game app","A way to catch computer viruses","A fraudulent attempt to steal information","A type of computer hardware"],correct:2},
         {question:"What should you do if you lose your phone?",options:["Nothing - it's just a phone","Use 'Find My Device' to lock or erase it","Post about it on social media","Keep trying to call it"],correct:1},
         {question:"Why should you avoid public WiFi for banking?",options:["It's too slow","Others on the network may intercept your data","Banks block public WiFi","It uses too much data"],correct:1},


        {question:"What is a 'zero-day' vulnerability?",options:["A calendar app bug","A security flaw unknown to the vendor","A problem that fixes itself in 24 hours","An issue that only appears at midnight"],correct:1},
        {question:"What does 'VPN' stand for?",options:["Virtual Private Network","Verified Personal Number","Visual Protection Notification","Voltage Power Node"],correct:0},
        {question:"What is 'end-to-end encryption'?",options:["Data scrambled so only sender and receiver can read it","A way to compress files","A method to speed up internet","A type of computer memory"],correct:0}
        ],
        "football":[
        
        {question:"How many players are on a football team during a match?",options:["9","10","11","12"],correct:2},
        {question:"Which trophy is awarded to the World Cup winners?",options:["Champions League","Ballon d'Or","FIFA World Cup","Premier League"],correct:2},
        {question:"What is the maximum number of substitutions allowed in most professional matches?",options:["3","5","7","Unlimited"],correct:1},
        {question:"Which country won the 2022 FIFA World Cup?",options:["France","Brazil","Argentina","Germany"],correct:2},


        {question:"Which player has won the most Ballon d'Or awards?",options:["Cristiano Ronaldo","Lionel Messi","Michel Platini","Johan Cruyff"],correct:1},
        {question:"What is the length of a standard football match in minutes?",options:["80","90","100","120"],correct:1},
        {question:"Which club has won the most UEFA Champions League titles?",options:["AC Milan","Bayern Munich","Real Madrid","Liverpool"],correct:2},


        {question:"Who was the first African player to win the Ballon d'Or?",options:["Didier Drogba","Samuel Eto'o","George Weah","Yaya Touré"],correct:2},
        {question:"Which year saw the introduction of the back-pass rule?",options:["1982","1992","2002","2012"],correct:1},
        {question:"Which nation hosted the first-ever World Cup?",options:["Brazil","Uruguay","Italy","France"],correct:1}
        ]
    };

    let currentQuiz = []; // To store the questions for the selected subcategory
    let currentQuestionIndex = 0; // Track the current question index
    let score = 0; // Track the user's score

    // Function to display a question
    function displayQuestion() {
        const questionData = currentQuiz[currentQuestionIndex];
        questionBox.textContent = questionData.question;

        // Clear previous options
        optionsContainer.innerHTML = "";

        // Add options
        questionData.options.forEach((option, index) => {
            const optionEl = document.createElement('div');
            optionEl.classList.add('option');
            optionEl.textContent = option;

            const circle = document.createElement('span');
            circle.classList.add('circle');
            optionEl.appendChild(circle);

            optionEl.addEventListener('click', () => {
                const allOptions = optionsContainer.querySelectorAll('.option');
                allOptions.forEach(opt => opt.classList.add('disabled')); // Disable all options after selection

                if (index === questionData.correct) {
                    optionEl.classList.add('correct');
                    circle.textContent = '✔';
                    score++;
                } else {
                    optionEl.classList.add('wrong');
                    circle.textContent = '✖';

                    // Highlight the correct answer
                    allOptions[questionData.correct].classList.add('correct');
                    allOptions[questionData.correct].querySelector('.circle').textContent = '✔';
                }

                updateProgress();
            });

            optionsContainer.appendChild(optionEl);
        });
    }

    // Function to update the progress bar
 function updateProgress() {
    const progress = ((currentQuestionIndex + 1) / currentQuiz.length) * 100;
    progressBar.style.width = `${progress}%`;
    progressText.textContent = `${currentQuestionIndex + 1}/${currentQuiz.length}`; // Update progress text
    console.log(progressText.textContent); // Debugging
}

   // Handle the "Next" button
nextButton.addEventListener('click', () => {
    const allOptions = optionsContainer.querySelectorAll('.option');
    const isAnswered = Array.from(allOptions).some(option => 
        option.classList.contains('correct') || option.classList.contains('wrong')
    );

    if (!isAnswered) {
        alert("Please choose an answer before proceeding to the next question.");
        return; // Stop execution if no answer is selected
    }

    if (currentQuestionIndex < currentQuiz.length - 1) {
        currentQuestionIndex++;
        displayQuestion(); // Display the next question
    } else {
        alert(`Quiz finished! Your score: ${score}/${currentQuiz.length}`);
        slidingQuizPage.classList.remove('active'); // Hide the quiz page
    }
});
    const closeButton = document.getElementById('closeQuiz'); // Select the close button

    closeButton.addEventListener('click', () => {
    slidingQuizPage.classList.remove('active'); // Hide the quiz page
});

    // Add click event listeners to subcategory cards
    quizCards.forEach(card => {
        card.addEventListener('click', () => {
            const subcategory = card.getAttribute('data-subcategory'); // Get the subcategory
            currentQuiz = allQuestions[subcategory] || []; // Load questions for the selected subcategory

            if (currentQuiz.length === 0) {
                alert("No questions for this subcategory yet.");
                return;
            }

            currentQuestionIndex = 0; // Reset to the first question
            score = 0; // Reset the score
            slidingQuizPage.classList.add('active'); // Show the quiz page
            displayQuestion(); // Display the first question
            updateProgress(); // Reset the progress bar
        });
    });
});